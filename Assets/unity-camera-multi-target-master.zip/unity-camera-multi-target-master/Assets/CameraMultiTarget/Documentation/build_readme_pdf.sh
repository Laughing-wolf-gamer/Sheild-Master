#!/usr/bin/env bash

pandoc README.md -s -o README.pdf --variable colorlinks=true -V geometry:margin=1.3in